# A-click Firefox版本
Firefox浏览器扩展，一键自动选择网页上所有"Yes"选项。支持智能检测、iframe支持和视觉反馈。

## 安装方法

### 方法1：临时安装（开发测试）
1. 打开Firefox浏览器
2. 在地址栏输入 `about:debugging`
3. 点击"此Firefox"
4. 点击"临时载入附加组件"
5. 选择 `manifest_firefox.json` 文件

### 方法2：打包安装
1. 将所有文件（除了Chrome版本的文件）打包成zip文件
2. 将zip文件重命名为 `.xpi` 扩展名
3. 在Firefox中打开该xpi文件进行安装

## 使用方法
1. 在任意网页上右键点击
2. 选择"Select All Yes Options"菜单项
3. 扩展会自动选择页面上所有"Yes"选项并高亮显示

## 功能特性
- 自动选择radio按钮中的"Yes"选项
- 自动选择checkbox中的"Yes"选项  
- 自动选择下拉菜单中的"Yes"选项
- 支持iframe内容检测
- 视觉高亮反馈
- 键盘快捷键支持（Ctrl+Shift+Y）

## 文件说明
- `manifest_firefox.json` - Firefox扩展配置文件
- `background_firefox.js` - Firefox后台脚本
- `content.js` - 内容脚本（与Chrome版本相同）
- `icons/` - 扩展图标文件夹

## 兼容性
- Firefox 57.0 及以上版本
- 支持所有现代网页标准