// Firefox版本的background脚本
// 创建右键菜单项
browser.runtime.onInstalled.addListener(() => {
  browser.contextMenus.create({
    id: "autoSelectFirst",
    title: "Select All Yes Options",
    contexts: ["all"]
  });
});

// 监听右键菜单点击事件
browser.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "autoSelectFirst") {
    // 向当前标签页注入content script
    browser.tabs.executeScript(tab.id, {
      file: 'content.js'
    });
  }
});